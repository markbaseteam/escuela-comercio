## Susan
- Inglés para la empresa: Sección 114
- Inglés para la logística: Sección 245

## Camilo
- Inglés para la Logística 1: Sección 244

## Valores
## Primer Trimestre

| Asignatura | Institución | Valor | Marzo | Abril | Mayo |
| - | - | - | - | - | - | 
| Inglés para el Marketing. Sección 131 | CFT | $85.344 | Pagado | Pagado | Pagado | 
| Inglés para la empresa. Sección 143 | CFT | $85.344  | Pagado  | Pagado | Pagado  | 
| Inglés I. Sección 1 | IP | $85.344 | Pagado | Pagado | Pagado  | 
| Inglés para el control de gestión. Sección 75 | IP | $84.220 | Pagado | Pagado | Pagado |
| Inglés para la Administración Comercial. Sección 65 | IP | $55.344  | Pagado | Pagado | Pagado |
| Inglés para la logística 1. Sección 114 | CFT | $85.344 | Pagado | Pagado | Pagado |

## Segundo Trimestre

| Asignatura| Institución| Valor| Junio| Julio| Agosto|
| - | - | - | - | - | - |
| Inglés I. Sección 106 | CFT | $95.281| Pagado| Pagado | Pagado|
| Inglés para la logística 2. Sección 45  | IP  | $105.332  | Pagado | Pagado | \*Pagado |
| Inglés para los recursos humanos. Sección 55 | IP | $124.588 | Pagado | Pagado | Pagado |

\*: Por cambio de alumnos, el monto en agosto es de 135.342.

## Tercer Trimestre

| Asignatura | Institución | Valor | SEP | OCT | NOV | DIC | ENE |
| - | - | - | - | - | - | - | - |
| Inglés para la Empresa. Sección 143 | CFT  | $86.867| Pagado | Pagado| X | X | X |
| Inglés para el Marketing I. Sección 151 | CFT | $86.867  | Pagado  | Pagado | X | X | X |
| Inglés para la logística. Sección 114 (6 meses) | CFT  | $130.280 | Pagado  | Pagado | Pagado | Pagado |  |
| Inglés para la logística. Sección 245 (3 meses) | CFT  | $95.404 | X | X | Pagado | Pagado |  |

## Datos Boleta
- CFT: 78.566.330-6 (Boleta 216).
- IP: 87.894.800-9 (Boleta 215).
